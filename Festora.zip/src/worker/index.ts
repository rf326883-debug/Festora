import { Hono } from "hono";
import { cors } from "hono/cors";
import { ProductSchema, ContactInquirySchema } from "../shared/types";
import { z } from "zod";
import { sign, verify } from "hono/jwt";

const CustomPhotoRequestSchema = z.object({
  full_name: z.string().min(1),
  phone_number: z.string().min(1),
  event_date: z.string().min(1),
  photo_url: z.string().min(1),
});


const app = new Hono<{ Bindings: Env }>();

app.use("*", cors());

// Google Analytics configuration endpoint
app.get("/api/analytics-config", async (c) => {
  try {
    const analyticsId = c.env.GOOGLE_ANALYTICS_ID;
    return c.json({ 
      analyticsId: analyticsId || null,
      enabled: !!analyticsId 
    });
  } catch (error) {
    console.error("Error fetching analytics config:", error);
    return c.json({ analyticsId: null, enabled: false });
  }
});

// Admin authentication middleware
const adminAuth = async (c: any, next: any) => {
  const authHeader = c.req.header('Authorization');
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return c.json({ error: 'Unauthorized' }, 401);
  }
  
  const token = authHeader.substring(7);
  
  try {
    const payload = await verify(token, c.env.ADMIN_PASSWORD);
    if (payload.admin !== true) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    await next();
  } catch (error) {
    return c.json({ error: 'Unauthorized' }, 401);
  }
};

// Admin login endpoint
app.post("/api/admin/login", async (c) => {
  try {
    const { password } = await c.req.json();
    
    if (password !== c.env.ADMIN_PASSWORD) {
      return c.json({ error: 'Invalid password' }, 401);
    }
    
    const token = await sign(
      { 
        admin: true,
        exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 hours
      },
      c.env.ADMIN_PASSWORD
    );
    
    return c.json({ success: true, token });
  } catch (error) {
    console.error("Login error:", error);
    return c.json({ error: "Authentication failed" }, 500);
  }
});



// Get products by category
app.get("/api/products/:category", async (c) => {
  const category = c.req.param("category");
  
  try {
    const stmt = c.env.DB.prepare("SELECT * FROM products WHERE category = ? ORDER BY created_at DESC");
    const { results } = await stmt.bind(category).all();
    
    const products = results.map(product => ProductSchema.parse(product));
    return c.json(products);
  } catch (error) {
    console.error("Error fetching products:", error);
    return c.json({ error: "Failed to fetch products" }, 500);
  }
});

// Get single product by ID
app.get("/api/products/details/:id", async (c) => {
  const id = parseInt(c.req.param("id"));
  
  try {
    const stmt = c.env.DB.prepare("SELECT * FROM products WHERE id = ?");
    const result = await stmt.bind(id).first();
    
    if (!result) {
      return c.json({ error: "Product not found" }, 404);
    }
    
    const product = ProductSchema.parse(result);
    return c.json(product);
  } catch (error) {
    console.error("Error fetching product:", error);
    return c.json({ error: "Failed to fetch product" }, 500);
  }
});

// Submit contact inquiry
app.post("/api/contact", async (c) => {
  try {
    const body = await c.req.json();
    const inquiry = ContactInquirySchema.parse(body);
    
    const stmt = c.env.DB.prepare(`
      INSERT INTO contact_inquiries (name, phone_number, product_id, product_name, event_date, message)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    
    await stmt.bind(
      inquiry.name,
      inquiry.phone_number,
      inquiry.product_id,
      inquiry.product_name,
      inquiry.event_date || null,
      inquiry.message || ""
    ).run();
    
    return c.json({ success: true, message: "Contact inquiry submitted successfully" });
  } catch (error) {
    console.error("Error submitting contact inquiry:", error);
    return c.json({ error: "Failed to submit inquiry" }, 500);
  }
});

// Upload image to R2
app.post("/api/upload", async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ error: "No file provided" }, 400);
    }

    // Generate unique filename
    const timestamp = Date.now();
    const randomId = Math.random().toString(36).substring(2, 15);
    const fileExtension = file.name.split('.').pop();
    const filename = `products/${timestamp}-${randomId}.${fileExtension}`;

    // Upload to R2
    await c.env.R2_BUCKET.put(filename, file, {
      httpMetadata: {
        contentType: file.type,
      },
    });

    return c.json({ 
      success: true, 
      filename,
      url: `/api/files/${filename}`
    });
  } catch (error) {
    console.error("Error uploading file:", error);
    return c.json({ error: "Failed to upload file" }, 500);
  }
});

// Serve images from R2
app.get("/api/files/*", async (c) => {
  const path = c.req.path.replace("/api/files/", "");
  
  try {
    const object = await c.env.R2_BUCKET.get(path);
    
    if (!object) {
      return c.json({ error: "File not found" }, 404);
    }

    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set("etag", object.httpEtag);
    headers.set("cache-control", "public, max-age=31536000");
    
    return c.body(object.body, { headers });
  } catch (error) {
    console.error("Error serving file:", error);
    return c.json({ error: "Failed to serve file" }, 500);
  }
});

// Protected Admin API endpoints

// Get all products for admin
app.get("/api/admin/products", adminAuth, async (c) => {
  try {
    const stmt = c.env.DB.prepare("SELECT * FROM products ORDER BY created_at DESC");
    const { results } = await stmt.all();
    
    const products = results.map(product => ProductSchema.parse(product));
    return c.json(products);
  } catch (error) {
    console.error("Error fetching all products:", error);
    return c.json({ error: "Failed to fetch products" }, 500);
  }
});

// Create new product
app.post("/api/admin/products", adminAuth, async (c) => {
  try {
    const body = await c.req.json();
    
    const productData = z.object({
      name: z.string().min(1),
      category: z.string().min(1),
      price: z.number().positive(),
      description: z.string().optional(),
      image_url: z.string().optional(),
    }).parse(body);
    
    const stmt = c.env.DB.prepare(`
      INSERT INTO products (name, category, price, description, image_url)
      VALUES (?, ?, ?, ?, ?)
    `);
    
    const result = await stmt.bind(
      productData.name,
      productData.category,
      productData.price,
      productData.description || "",
      productData.image_url || ""
    ).run();
    
    return c.json({ 
      success: true, 
      id: result.meta.last_row_id,
      message: "Product created successfully" 
    });
  } catch (error) {
    console.error("Error creating product:", error);
    return c.json({ error: "Failed to create product" }, 500);
  }
});

// Update product
app.put("/api/admin/products/:id", adminAuth, async (c) => {
  const id = parseInt(c.req.param("id"));
  
  try {
    const body = await c.req.json();
    
    const productData = z.object({
      name: z.string().min(1),
      category: z.string().min(1),
      price: z.number().positive(),
      description: z.string().optional(),
      image_url: z.string().optional(),
    }).parse(body);
    
    const stmt = c.env.DB.prepare(`
      UPDATE products 
      SET name = ?, category = ?, price = ?, description = ?, image_url = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    await stmt.bind(
      productData.name,
      productData.category,
      productData.price,
      productData.description || "",
      productData.image_url || "",
      id
    ).run();
    
    return c.json({ success: true, message: "Product updated successfully" });
  } catch (error) {
    console.error("Error updating product:", error);
    return c.json({ error: "Failed to update product" }, 500);
  }
});

// Delete product
app.delete("/api/admin/products/:id", adminAuth, async (c) => {
  const id = parseInt(c.req.param("id"));
  
  try {
    // Get product to check if it has an image
    const getStmt = c.env.DB.prepare("SELECT image_url FROM products WHERE id = ?");
    const product = await getStmt.bind(id).first() as any;
    
    if (product?.image_url?.startsWith('/api/files/')) {
      // Delete image from R2
      const filename = product.image_url.replace('/api/files/', '');
      try {
        await c.env.R2_BUCKET.delete(filename);
      } catch (error) {
        console.error("Error deleting image from R2:", error);
      }
    }
    
    // Delete product from database
    const deleteStmt = c.env.DB.prepare("DELETE FROM products WHERE id = ?");
    await deleteStmt.bind(id).run();
    
    return c.json({ success: true, message: "Product deleted successfully" });
  } catch (error) {
    console.error("Error deleting product:", error);
    return c.json({ error: "Failed to delete product" }, 500);
  }
});

// Submit custom photo request
app.post("/api/custom-photo-request", async (c) => {
  try {
    const body = await c.req.json();
    const request = CustomPhotoRequestSchema.parse(body);
    
    const stmt = c.env.DB.prepare(`
      INSERT INTO custom_photo_requests (full_name, phone_number, event_date, photo_url)
      VALUES (?, ?, ?, ?)
    `);
    
    await stmt.bind(
      request.full_name,
      request.phone_number,
      request.event_date,
      request.photo_url
    ).run();
    
    return c.json({ success: true, message: "Custom photo request submitted successfully" });
  } catch (error) {
    console.error("Error submitting custom photo request:", error);
    return c.json({ error: "Failed to submit request" }, 500);
  }
});

// Get custom photo requests for admin
app.get("/api/admin/custom-photo-requests", adminAuth, async (c) => {
  try {
    const stmt = c.env.DB.prepare("SELECT * FROM custom_photo_requests ORDER BY created_at DESC");
    const { results } = await stmt.all();
    
    return c.json(results);
  } catch (error) {
    console.error("Error fetching custom photo requests:", error);
    return c.json({ error: "Failed to fetch requests" }, 500);
  }
});

// Mark custom photo request as reviewed
app.put("/api/admin/custom-photo-requests/:id/reviewed", adminAuth, async (c) => {
  const id = parseInt(c.req.param("id"));
  
  try {
    const stmt = c.env.DB.prepare(`
      UPDATE custom_photo_requests 
      SET is_reviewed = TRUE, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    await stmt.bind(id).run();
    
    return c.json({ success: true, message: "Request marked as reviewed" });
  } catch (error) {
    console.error("Error updating request:", error);
    return c.json({ error: "Failed to update request" }, 500);
  }
});

// Get contact inquiries for admin
app.get("/api/admin/contact-inquiries", adminAuth, async (c) => {
  try {
    const stmt = c.env.DB.prepare("SELECT * FROM contact_inquiries ORDER BY created_at DESC");
    const { results } = await stmt.all();
    
    return c.json(results);
  } catch (error) {
    console.error("Error fetching contact inquiries:", error);
    return c.json({ error: "Failed to fetch inquiries" }, 500);
  }
});

// Mark contact inquiry as reviewed
app.put("/api/admin/contact-inquiries/:id/reviewed", adminAuth, async (c) => {
  const id = parseInt(c.req.param("id"));
  
  try {
    const stmt = c.env.DB.prepare(`
      UPDATE contact_inquiries 
      SET is_reviewed = TRUE, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    await stmt.bind(id).run();
    
    return c.json({ success: true, message: "Inquiry marked as reviewed" });
  } catch (error) {
    console.error("Error updating inquiry:", error);
    return c.json({ error: "Failed to update inquiry" }, 500);
  }
});

export default app;
