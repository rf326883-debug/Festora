import z from "zod";

export const ProductSchema = z.object({
  id: z.number(),
  name: z.string(),
  category: z.string(),
  price: z.number(),
  description: z.string().optional(),
  image_url: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Product = z.infer<typeof ProductSchema>;

export const ContactInquirySchema = z.object({
  name: z.string().min(1, "Name is required"),
  phone_number: z.string().min(10, "Phone number must be at least 10 digits"),
  product_id: z.number(),
  product_name: z.string(),
  event_date: z.string().optional(),
  message: z.string().optional(),
});

export type ContactInquiry = z.infer<typeof ContactInquirySchema>;

export const EventCategories = [
  'Birthday',
  'Haldi', 
  'Baby Shower',
  'Half Saree Ceremony',
  'Engagement',
  'Housewarming Ceremony'
] as const;

export type EventCategory = typeof EventCategories[number];
