import { useState, useEffect } from 'react';
import { Product, EventCategories } from '@/shared/types';
import { Plus, Edit2, Trash2, Upload, X, Save, Image as ImageIcon, Camera, Phone, Calendar, User, Check, Eye, LogOut } from 'lucide-react';
import AdminLogin from '@/react-app/components/AdminLogin';

interface ProductFormData {
  name: string;
  category: string;
  price: number;
  description: string;
  image_url: string;
}

interface CustomPhotoRequest {
  id: number;
  full_name: string;
  phone_number: string;
  event_date: string;
  photo_url: string;
  is_reviewed: boolean;
  created_at: string;
  updated_at: string;
}

interface ContactInquiry {
  id: number;
  name: string;
  phone_number: string;
  product_id: number;
  product_name: string;
  event_date: string;
  message: string;
  is_reviewed: boolean;
  created_at: string;
  updated_at: string;
}

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [customRequests, setCustomRequests] = useState<CustomPhotoRequest[]>([]);
  const [contactInquiries, setContactInquiries] = useState<ContactInquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [uploading, setUploading] = useState(false);
  const [activeTab, setActiveTab] = useState<'products' | 'requests' | 'inquiries'>('products');
  const [formData, setFormData] = useState<ProductFormData>({
    name: '',
    category: EventCategories[0],
    price: 0,
    description: '',
    image_url: '',
  });

  useEffect(() => {
    // Load Google Fonts
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    // Check for existing auth token
    const savedToken = sessionStorage.getItem('admin_token');
    if (savedToken) {
      setAuthToken(savedToken);
      setIsAuthenticated(true);
    }

    return () => {
      document.head.removeChild(link);
    };
  }, []);

  useEffect(() => {
    if (isAuthenticated && authToken) {
      fetchProducts();
      fetchCustomRequests();
      fetchContactInquiries();
    }
  }, [isAuthenticated, authToken]);

  const handleLogin = async (password: string): Promise<boolean> => {
    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ password }),
      });

      if (response.ok) {
        const data = await response.json();
        const token = data.token;
        setAuthToken(token);
        setIsAuthenticated(true);
        sessionStorage.setItem('admin_token', token);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setAuthToken(null);
    sessionStorage.removeItem('admin_token');
    setProducts([]);
    setCustomRequests([]);
    setContactInquiries([]);
  };

  const getAuthHeaders = () => ({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${authToken}`,
  });

  const fetchProducts = async () => {
    try {
      const response = await fetch('/api/admin/products', {
        headers: getAuthHeaders(),
      });
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      } else if (response.status === 401) {
        handleLogout();
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomRequests = async () => {
    try {
      const response = await fetch('/api/admin/custom-photo-requests', {
        headers: getAuthHeaders(),
      });
      if (response.ok) {
        const data = await response.json();
        setCustomRequests(data);
      } else if (response.status === 401) {
        handleLogout();
      }
    } catch (error) {
      console.error('Error fetching custom requests:', error);
    }
  };

  const fetchContactInquiries = async () => {
    try {
      const response = await fetch('/api/admin/contact-inquiries', {
        headers: getAuthHeaders(),
      });
      if (response.ok) {
        const data = await response.json();
        setContactInquiries(data);
      } else if (response.status === 401) {
        handleLogout();
      }
    } catch (error) {
      console.error('Error fetching contact inquiries:', error);
    }
  };

  const handleImageUpload = async (file: File) => {
    if (!file) return;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        setFormData(prev => ({ ...prev, image_url: data.url }));
      } else {
        alert('Failed to upload image');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      alert('Error uploading image');
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const url = editingProduct 
        ? `/api/admin/products/${editingProduct.id}`
        : '/api/admin/products';
      
      const method = editingProduct ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: getAuthHeaders(),
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        await fetchProducts();
        resetForm();
        alert(editingProduct ? 'Product updated successfully!' : 'Product created successfully!');
      } else {
        alert('Failed to save product');
      }
    } catch (error) {
      console.error('Error saving product:', error);
      alert('Error saving product');
    }
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      category: product.category,
      price: product.price,
      description: product.description || '',
      image_url: product.image_url || '',
    });
    setShowForm(true);
  };

  const handleDelete = async (product: Product) => {
    if (!confirm(`Are you sure you want to delete "${product.name}"?`)) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/products/${product.id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        await fetchProducts();
        alert('Product deleted successfully!');
      } else {
        alert('Failed to delete product');
      }
    } catch (error) {
      console.error('Error deleting product:', error);
      alert('Error deleting product');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      category: EventCategories[0],
      price: 0,
      description: '',
      image_url: '',
    });
    setEditingProduct(null);
    setShowForm(false);
  };

  const markAsReviewed = async (requestId: number) => {
    try {
      const response = await fetch(`/api/admin/custom-photo-requests/${requestId}/reviewed`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        await fetchCustomRequests();
        alert('Request marked as reviewed!');
      } else {
        alert('Failed to update request');
      }
    } catch (error) {
      console.error('Error updating request:', error);
      alert('Error updating request');
    }
  };

  const markInquiryAsReviewed = async (inquiryId: number) => {
    try {
      const response = await fetch(`/api/admin/contact-inquiries/${inquiryId}/reviewed`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        await fetchContactInquiries();
        alert('Inquiry marked as reviewed!');
      } else {
        alert('Failed to update inquiry');
      }
    } catch (error) {
      console.error('Error updating inquiry:', error);
      alert('Error updating inquiry');
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  // Show login form if not authenticated
  if (!isAuthenticated) {
    return <AdminLogin onLogin={handleLogin} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-purple-100">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-800" style={{ fontFamily: 'Playfair Display, serif' }}>
                Festora Admin
              </h1>
              <p className="text-gray-600">Manage your decoration packages</p>
            </div>
            <div className="flex items-center space-x-4">
              {/* Tab Navigation */}
              <div className="flex bg-gray-100 rounded-xl p-1">
                <button
                  onClick={() => setActiveTab('products')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    activeTab === 'products'
                      ? 'bg-white text-purple-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  Products
                </button>
                <button
                  onClick={() => setActiveTab('inquiries')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    activeTab === 'inquiries'
                      ? 'bg-white text-purple-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  Package Inquiries
                  {contactInquiries.filter(inq => !inq.is_reviewed).length > 0 && (
                    <span className="ml-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                      {contactInquiries.filter(inq => !inq.is_reviewed).length}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setActiveTab('requests')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    activeTab === 'requests'
                      ? 'bg-white text-purple-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  Custom Requests
                  {customRequests.filter(req => !req.is_reviewed).length > 0 && (
                    <span className="ml-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                      {customRequests.filter(req => !req.is_reviewed).length}
                    </span>
                  )}
                </button>
              </div>
              
              <div className="flex items-center space-x-4">
                {activeTab === 'products' && (
                  <button
                    onClick={() => setShowForm(true)}
                    className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-xl font-medium shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
                  >
                    <Plus className="w-5 h-5" />
                    <span>Add Product</span>
                  </button>
                )}
                
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-xl font-medium shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 py-8">
        {activeTab === 'products' ? (
          // Products Tab
          products.length === 0 ? (
            <div className="text-center py-12">
              <ImageIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-600 mb-2">No products yet</h3>
              <p className="text-gray-500 mb-4">Start by adding your first decoration package</p>
              <button
                onClick={() => setShowForm(true)}
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
              >
                Add Your First Product
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <div key={product.id} className="bg-white rounded-2xl shadow-lg overflow-hidden">
                  <div className="aspect-square relative">
                    <img
                      src={product.image_url || 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=400&auto=format&fit=crop'}
                      alt={product.name}
                      className="w-full h-full object-contain"
                    />
                    <div className="absolute top-3 right-3 flex space-x-2">
                      <button
                        onClick={() => handleEdit(product)}
                        className="p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-lg hover:bg-white transition-colors"
                      >
                        <Edit2 className="w-4 h-4 text-gray-700" />
                      </button>
                      <button
                        onClick={() => handleDelete(product)}
                        className="p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-lg hover:bg-red-50 transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-800 mb-1" style={{ fontFamily: 'Playfair Display, serif' }}>
                      {product.name}
                    </h3>
                    <p className="text-sm text-purple-600 mb-2">{product.category}</p>
                    <p className="text-lg font-bold text-gray-800">
                      {formatPrice(product.price)}
                    </p>
                    {product.description && (
                      <p className="text-sm text-gray-600 mt-2 line-clamp-2">
                        {product.description}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )
        ) : activeTab === 'inquiries' ? (
          // Package Inquiries Tab
          contactInquiries.length === 0 ? (
            <div className="text-center py-12">
              <Phone className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-600 mb-2">No package inquiries yet</h3>
              <p className="text-gray-500">Customer inquiries from product pages will appear here</p>
            </div>
          ) : (
            <div className="space-y-6">
              {contactInquiries.map((inquiry) => (
                <div key={inquiry.id} className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${
                  inquiry.is_reviewed ? 'border-green-200' : 'border-orange-200'
                }`}>
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-gray-800 mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                          Package Inquiry
                        </h3>
                        <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                          inquiry.is_reviewed 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-orange-100 text-orange-800'
                        }`}>
                          {inquiry.is_reviewed ? (
                            <>
                              <Check className="w-4 h-4 mr-1" />
                              Reviewed
                            </>
                          ) : (
                            <>
                              <Eye className="w-4 h-4 mr-1" />
                              Pending Review
                            </>
                          )}
                        </div>
                      </div>
                      
                      {!inquiry.is_reviewed && (
                        <button
                          onClick={() => markInquiryAsReviewed(inquiry.id)}
                          className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-xl font-medium shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
                        >
                          <Check className="w-4 h-4" />
                          <span>Mark as Reviewed</span>
                        </button>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center space-x-3">
                        <User className="w-5 h-5 text-purple-600" />
                        <div>
                          <p className="text-sm text-gray-500">Customer Name</p>
                          <p className="font-medium text-gray-800">{inquiry.name}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <Phone className="w-5 h-5 text-purple-600" />
                        <div>
                          <p className="text-sm text-gray-500">Phone Number</p>
                          <p className="font-medium text-gray-800">{inquiry.phone_number}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3 md:col-span-2">
                        <ImageIcon className="w-5 h-5 text-purple-600" />
                        <div>
                          <p className="text-sm text-gray-500">Inquired Product</p>
                          <p className="font-medium text-gray-800">{inquiry.product_name}</p>
                        </div>
                      </div>
                      
                      {inquiry.event_date && (
                        <div className="flex items-center space-x-3 md:col-span-2">
                          <Calendar className="w-5 h-5 text-purple-600" />
                          <div>
                            <p className="text-sm text-gray-500">Event Date</p>
                            <p className="font-medium text-gray-800">
                              {new Date(inquiry.event_date).toLocaleDateString('en-US', {
                                weekday: 'long',
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                              })}
                            </p>
                          </div>
                        </div>
                      )}
                      
                      {inquiry.message && (
                        <div className="flex items-start space-x-3 md:col-span-2">
                          <Camera className="w-5 h-5 text-purple-600 mt-1" />
                          <div>
                            <p className="text-sm text-gray-500">Customer Message</p>
                            <p className="font-medium text-gray-800">{inquiry.message}</p>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex items-center space-x-3">
                        <Calendar className="w-5 h-5 text-purple-600" />
                        <div>
                          <p className="text-sm text-gray-500">Submitted</p>
                          <p className="font-medium text-gray-800">
                            {new Date(inquiry.created_at).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                            })}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : (
          // Custom Requests Tab
          customRequests.length === 0 ? (
            <div className="text-center py-12">
              <Camera className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-600 mb-2">No custom requests yet</h3>
              <p className="text-gray-500">Customer photo requests will appear here</p>
            </div>
          ) : (
            <div className="space-y-6">
              {customRequests.map((request) => (
                <div key={request.id} className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${
                  request.is_reviewed ? 'border-green-200' : 'border-orange-200'
                }`}>
                  <div className="md:flex">
                    {/* Photo */}
                    <div className="md:w-1/3">
                      <img
                        src={request.photo_url}
                        alt="Customer decoration request"
                        className="w-full h-64 md:h-full object-contain"
                      />
                    </div>
                    
                    {/* Details */}
                    <div className="md:w-2/3 p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-xl font-semibold text-gray-800 mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                            Custom Decoration Request
                          </h3>
                          <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                            request.is_reviewed 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-orange-100 text-orange-800'
                          }`}>
                            {request.is_reviewed ? (
                              <>
                                <Check className="w-4 h-4 mr-1" />
                                Reviewed
                              </>
                            ) : (
                              <>
                                <Eye className="w-4 h-4 mr-1" />
                                Pending Review
                              </>
                            )}
                          </div>
                        </div>
                        
                        {!request.is_reviewed && (
                          <button
                            onClick={() => markAsReviewed(request.id)}
                            className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-xl font-medium shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
                          >
                            <Check className="w-4 h-4" />
                            <span>Mark as Reviewed</span>
                          </button>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="flex items-center space-x-3">
                          <User className="w-5 h-5 text-purple-600" />
                          <div>
                            <p className="text-sm text-gray-500">Customer Name</p>
                            <p className="font-medium text-gray-800">{request.full_name}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <Phone className="w-5 h-5 text-purple-600" />
                          <div>
                            <p className="text-sm text-gray-500">Phone Number</p>
                            <p className="font-medium text-gray-800">{request.phone_number}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <Calendar className="w-5 h-5 text-purple-600" />
                          <div>
                            <p className="text-sm text-gray-500">Event Date</p>
                            <p className="font-medium text-gray-800">
                              {new Date(request.event_date).toLocaleDateString('en-US', {
                                weekday: 'long',
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                              })}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <Camera className="w-5 h-5 text-purple-600" />
                          <div>
                            <p className="text-sm text-gray-500">Submitted</p>
                            <p className="font-medium text-gray-800">
                              {new Date(request.created_at).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric',
                              })}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
      </div>

      {/* Product Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl">
            {/* Header */}
            <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 rounded-t-2xl">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-800" style={{ fontFamily: 'Playfair Display, serif' }}>
                  {editingProduct ? 'Edit Product' : 'Add New Product'}
                </h2>
                <button
                  onClick={resetForm}
                  className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Image Upload */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Product Image
                </label>
                <div className="space-y-3">
                  {formData.image_url && (
                    <div className="relative">
                      <img
                        src={formData.image_url}
                        alt="Preview"
                        className="w-full h-32 object-contain rounded-xl"
                      />
                      <button
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, image_url: '' }))}
                        className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded-full hover:bg-red-700 transition-colors"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                  <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-gray-300 border-dashed rounded-xl cursor-pointer bg-gray-50 hover:bg-gray-100">
                    <div className="flex flex-col items-center justify-center pt-2 pb-2">
                      {uploading ? (
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-purple-600"></div>
                      ) : (
                        <>
                          <Upload className="w-6 h-6 text-gray-400 mb-1" />
                          <p className="text-xs text-gray-500">Click to upload image</p>
                        </>
                      )}
                    </div>
                    <input
                      type="file"
                      className="hidden"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleImageUpload(file);
                      }}
                      disabled={uploading}
                    />
                  </label>
                </div>
              </div>

              {/* Name */}
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                  Product Name *
                </label>
                <input
                  type="text"
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                  placeholder="e.g., Golden Birthday Decoration"
                />
              </div>

              {/* Category */}
              <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
                  Category *
                </label>
                <select
                  id="category"
                  value={formData.category}
                  onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                >
                  {EventCategories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>

              {/* Price */}
              <div>
                <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-2">
                  Price (₹) *
                </label>
                <input
                  type="number"
                  id="price"
                  value={formData.price}
                  onChange={(e) => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                  required
                  min="0"
                  step="100"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                  placeholder="e.g., 5000"
                />
              </div>

              {/* Description */}
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                  Description (Optional)
                </label>
                <textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all resize-none"
                  placeholder="Describe what's included in this decoration package..."
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 px-6 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95 transition-all duration-200 flex items-center justify-center space-x-2"
              >
                <Save className="w-5 h-5" />
                <span>{editingProduct ? 'Update Product' : 'Create Product'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
