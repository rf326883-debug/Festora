import { useParams, useNavigate } from 'react-router';
import { useEffect, useState } from 'react';
import { Product } from '@/shared/types';
import { ArrowLeft, Heart, MessageCircle, Sparkles } from 'lucide-react';
import ContactForm from '@/react-app/components/ContactForm';
import { useAnalytics } from '@/react-app/hooks/useAnalytics';

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showContactForm, setShowContactForm] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const { trackProductView, trackEvent } = useAnalytics();

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      
      try {
        setLoading(true);
        const response = await fetch(`/api/products/details/${id}`);
        
        if (!response.ok) {
          throw new Error('Product not found');
        }
        
        const data = await response.json();
        setProduct(data);
        
        // Track product view
        trackProductView(data.id, data.name, data.category);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading decoration details...</p>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">{error || 'Product not found'}</p>
          <button 
            onClick={() => navigate('/')}
            className="text-purple-600 hover:text-purple-700"
          >
            Go back home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white/90 backdrop-blur-md border-b border-purple-100">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => navigate(-1)}
              className="p-2 rounded-full hover:bg-purple-100 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-700" />
            </button>
            <button className="p-2 rounded-full hover:bg-purple-100 transition-colors">
              <Heart className="w-5 h-5 text-gray-700 hover:text-red-500 transition-colors" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-6">
        {/* Product Image */}
        <div className="relative mb-6 rounded-2xl overflow-hidden bg-white shadow-lg">
          <div className="aspect-square relative">
            {!imageLoaded && (
              <div className="absolute inset-0 bg-gray-200 animate-pulse flex items-center justify-center">
                <Sparkles className="w-8 h-8 text-gray-400" />
              </div>
            )}
            <img
              src={product.image_url || 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=800&auto=format&fit=crop'}
              alt={product.name}
              className={`w-full h-full object-contain transition-opacity duration-300 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
              onLoad={() => setImageLoaded(true)}
            />
            
            {/* Price overlay */}
            <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-sm rounded-2xl px-4 py-3 shadow-lg">
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">
                  {formatPrice(product.price)}
                </p>
                <p className="text-xs text-gray-600 mt-1">(Negotiable)</p>
              </div>
            </div>

            
          </div>
        </div>

        {/* Product Info */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="mb-4">
            <h1 className="text-2xl font-bold text-gray-800 mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
              {product.name}
            </h1>
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full font-medium">
                {product.category}
              </span>
            </div>
          </div>

          {product.description && (
            <div className="mb-6">
              <h3 className="font-semibold text-gray-800 mb-2">Description</h3>
              <p className="text-gray-600 leading-relaxed">
                {product.description}
              </p>
            </div>
          )}

          

          {/* Price details */}
          <div className="border-t border-gray-100 pt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600">Decoration Package</span>
              <span className="font-semibold text-gray-800">{formatPrice(product.price)} <span className="text-sm text-gray-600 font-normal">(Negotiable)</span></span>
            </div>
            <div className="flex items-center justify-between text-sm text-gray-500">
              <span>Setup & Clean-up included</span>
              <span>Free consultation</span>
            </div>
          </div>
        </div>

        {/* Contact Button */}
        <div className="sticky bottom-6 z-10">
          <button
            onClick={() => {
              setShowContactForm(true);
              trackEvent('click_contact_button', 'engagement', product.name);
            }}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-4 px-6 rounded-2xl font-semibold shadow-xl hover:shadow-2xl transform hover:scale-105 active:scale-95 transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <MessageCircle className="w-5 h-5" />
            <span>Contact Us for This Package</span>
          </button>
        </div>
      </div>

      {/* Contact Form Modal */}
      {showContactForm && (
        <ContactForm
          product={product}
          onClose={() => setShowContactForm(false)}
        />
      )}
    </div>
  );
}
