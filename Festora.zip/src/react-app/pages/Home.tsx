import { useNavigate } from 'react-router';
import { EventCategories } from '@/shared/types';
import { Sparkles, Heart, Gift, Crown, Flower, Home as HomeIcon, Camera, ArrowRight } from 'lucide-react';
import { useEffect } from 'react';

const categoryIcons = {
  'Birthday': Gift,
  'Haldi': Flower,
  'Baby Shower': Heart,
  'Half Saree Ceremony': Crown,
  'Engagement': Sparkles,
  'Housewarming Ceremony': HomeIcon,
};

const categoryColors = {
  'Birthday': 'from-pink-400 to-purple-500',
  'Haldi': 'from-yellow-400 to-orange-500',
  'Baby Shower': 'from-blue-400 to-cyan-500',
  'Half Saree Ceremony': 'from-purple-400 to-pink-500',
  'Engagement': 'from-rose-400 to-red-500',
  'Housewarming Ceremony': 'from-green-400 to-teal-500',
};

export default function Home() {
  const navigate = useNavigate();

  useEffect(() => {
    // Load Google Fonts
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    return () => {
      document.head.removeChild(link);
    };
  }, []);

  const handleCategorySelect = (category: string) => {
    navigate(`/category/${encodeURIComponent(category)}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="relative overflow-hidden bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 px-6 py-12">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 via-pink-600/20 to-rose-600/20 backdrop-blur-sm"></div>
        <div className="relative text-center">
          <div className="mb-4">
            <Sparkles className="w-12 h-12 text-white mx-auto animate-pulse" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
            Welcome to Festora
          </h1>
          <p className="text-white/90 text-lg font-light" style={{ fontFamily: 'Inter, sans-serif' }}>
            Where Every Celebration Becomes Magical
          </p>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-4 left-4 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
        <div className="absolute bottom-4 right-4 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-white/5 rounded-full blur-3xl"></div>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        <div className="max-w-md mx-auto">
          <h2 className="text-2xl font-semibold text-gray-800 text-center mb-8" style={{ fontFamily: 'Playfair Display, serif' }}>
            What type of event are you celebrating?
          </h2>

          <div className="grid grid-cols-2 gap-4">
            {EventCategories.map((category) => {
              const Icon = categoryIcons[category];
              const colorClass = categoryColors[category];
              
              return (
                <button
                  key={category}
                  onClick={() => handleCategorySelect(category)}
                  className="group relative overflow-hidden rounded-2xl p-6 bg-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 active:scale-95"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${colorClass} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}></div>
                  
                  <div className="relative z-10 text-center">
                    <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-br ${colorClass} mb-3 group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-medium text-gray-800 text-sm leading-tight" style={{ fontFamily: 'Inter, sans-serif' }}>
                      {category}
                    </h3>
                  </div>
                  
                  {/* Shimmer effect */}
                  <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
                </button>
              );
            })}
          </div>

          {/* Bottom decoration */}
          <div className="mt-12 text-center">
            <div className="inline-flex items-center space-x-2 text-gray-500">
              <div className="w-8 h-0.5 bg-gradient-to-r from-transparent to-purple-300"></div>
              <Sparkles className="w-4 h-4 text-purple-400" />
              <div className="w-8 h-0.5 bg-gradient-to-l from-transparent to-purple-300"></div>
            </div>
            <p className="text-sm text-gray-600 mt-3" style={{ fontFamily: 'Inter, sans-serif' }}>
              Creating beautiful memories, one celebration at a time
            </p>
            
            {/* Admin Access - Hidden link */}
            <div className="mt-8">
              <a 
                href="/admin"
                className="text-xs text-gray-400 hover:text-purple-600 transition-colors"
              >
                Admin Access
              </a>
            </div>
          </div>
        </div>

        {/* Custom Photo Upload Section */}
        <div className="mt-16">
          <div className="bg-white rounded-3xl p-8 shadow-lg border border-purple-100 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Camera className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
              Upload your own picture and get the best prices for your decoration!
            </h3>
            <p className="text-gray-600 mb-6">
              Check the best negotiable prices now.
            </p>
            
            <button
              onClick={() => navigate('/custom-upload')}
              className="inline-flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 px-8 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95 transition-all duration-200"
            >
              <Camera className="w-5 h-5" />
              <span>Upload Photo & Get Quotes</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
