import { useNavigate } from 'react-router';
import { ArrowLeft } from 'lucide-react';
import CustomPhotoUpload from '@/react-app/components/CustomPhotoUpload';
import { useEffect } from 'react';

export default function CustomPhotoUploadPage() {
  const navigate = useNavigate();

  useEffect(() => {
    // Load Google Fonts
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    return () => {
      document.head.removeChild(link);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="relative overflow-hidden bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 px-6 py-8">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 via-pink-600/20 to-rose-600/20 backdrop-blur-sm"></div>
        <div className="relative flex items-center">
          <button
            onClick={() => navigate('/')}
            className="mr-4 p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-white" style={{ fontFamily: 'Playfair Display, serif' }}>
              Custom Photo Upload
            </h1>
            <p className="text-white/90 text-lg font-light" style={{ fontFamily: 'Inter, sans-serif' }}>
              Get personalized quotes for your decoration
            </p>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-4 left-4 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
        <div className="absolute bottom-4 right-4 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        <div className="max-w-md mx-auto">
          <CustomPhotoUpload />
        </div>
      </div>
    </div>
  );
}
