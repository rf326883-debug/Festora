import { useEffect } from 'react';

interface AnalyticsConfig {
  analyticsId: string | null;
  enabled: boolean;
}

declare global {
  interface Window {
    gtag: (...args: any[]) => void;
    dataLayer: any[];
  }
}

export const useAnalytics = () => {
  useEffect(() => {
    const initializeAnalytics = async () => {
      try {
        const response = await fetch('/api/analytics-config');
        const config: AnalyticsConfig = await response.json();
        
        if (config.enabled && config.analyticsId) {
          // Replace placeholder with actual analytics ID
          const analyticsId = config.analyticsId;
          const scripts = document.querySelectorAll('script');
          scripts.forEach(script => {
            if (script.innerHTML && script.innerHTML.includes('GA_MEASUREMENT_ID')) {
              script.innerHTML = script.innerHTML.replace(/GA_MEASUREMENT_ID/g, analyticsId);
            }
            if (script.src && script.src.includes('GA_MEASUREMENT_ID')) {
              script.src = script.src.replace('GA_MEASUREMENT_ID', analyticsId);
            }
          });
          
          // Track initial page view
          if (window.gtag) {
            window.gtag('config', config.analyticsId, {
              page_title: document.title,
              page_location: window.location.href,
            });
          }
        }
      } catch (error) {
        console.error('Failed to initialize analytics:', error);
      }
    };

    initializeAnalytics();
  }, []);

  const trackPageView = (page_title: string, page_location?: string) => {
    if (window.gtag) {
      window.gtag('event', 'page_view', {
        page_title,
        page_location: page_location || window.location.href,
      });
    }
  };

  const trackEvent = (action: string, category?: string, label?: string, value?: number) => {
    if (window.gtag) {
      window.gtag('event', action, {
        event_category: category,
        event_label: label,
        value: value,
      });
    }
  };

  const trackProductView = (productId: number, productName: string, category: string) => {
    if (window.gtag) {
      window.gtag('event', 'view_item', {
        currency: 'INR',
        value: 0,
        items: [{
          item_id: productId.toString(),
          item_name: productName,
          item_category: category,
        }]
      });
    }
  };

  const trackContactSubmission = (productName: string) => {
    if (window.gtag) {
      window.gtag('event', 'generate_lead', {
        currency: 'INR',
        value: 1,
        event_category: 'engagement',
        event_label: productName,
      });
    }
  };

  return {
    trackPageView,
    trackEvent,
    trackProductView,
    trackContactSubmission,
  };
};
