import { BrowserRouter as Router, Routes, Route } from "react-router";
import HomePage from "@/react-app/pages/Home";
import ProductGalleryPage from "@/react-app/pages/ProductGallery";
import ProductDetailPage from "@/react-app/pages/ProductDetail";
import AdminPage from "@/react-app/pages/Admin";
import CustomPhotoUploadPage from "@/react-app/pages/CustomPhotoUpload";
import { useAnalytics } from "@/react-app/hooks/useAnalytics";

export default function App() {
  // Initialize Google Analytics
  useAnalytics();

  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/category/:category" element={<ProductGalleryPage />} />
        <Route path="/product/:id" element={<ProductDetailPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/custom-upload" element={<CustomPhotoUploadPage />} />
      </Routes>
    </Router>
  );
}
