
ALTER TABLE contact_inquiries ADD COLUMN is_reviewed BOOLEAN DEFAULT FALSE;
