
CREATE TABLE custom_photo_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  phone_number TEXT NOT NULL,
  event_date DATE NOT NULL,
  photo_url TEXT NOT NULL,
  is_reviewed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_custom_photo_requests_created_at ON custom_photo_requests(created_at);
CREATE INDEX idx_custom_photo_requests_is_reviewed ON custom_photo_requests(is_reviewed);
