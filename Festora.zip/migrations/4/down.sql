
ALTER TABLE contact_inquiries DROP COLUMN is_reviewed;
