
ALTER TABLE contact_inquiries ADD COLUMN event_date DATE;
