
ALTER TABLE contact_inquiries DROP COLUMN event_date;
