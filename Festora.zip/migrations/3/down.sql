
DELETE FROM products WHERE image_url LIKE 'https://mocha-cdn.com/019a1fc4-fe39-77d0-baa1-bbb2bea882c0/%';
