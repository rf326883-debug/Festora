
DROP INDEX idx_contact_inquiries_product_id;
DROP INDEX idx_products_category;
DROP TABLE contact_inquiries;
DROP TABLE products;
